class Persona:
  def _init_(self, nombre, direccion, telefono):
    self.nombre = nombre
    self.direccion = direccion
    self.telefono = telefono
  def mostrar(self): 
    print (self.nombre,self.direccion,self.telefono)

class Cliente(Persona):
  def _init_(self, nombre, direccion, telefono, ):
    super()._init_(nombre, direccion, telefono)
  def mostrar(self):

class Empleado(Persona):
  def _init_(self, nombre, direccion, telefono):
    super()._init_(nombre, direccion, telefono)
  def mostrar(self):


# Crear un nuevo cliente.
cliente = Cliente('Juan Pérez', '123 Calle Principal', '555-123-4567')

# Crear un nuevo empleado.
empleado = Empleado('María García', '456 Avenida de los Robles', '555-234-5678')

# Imprimir el nombre del cliente.
print(cliente.nombre)

# Imprimir la dirección del empleado.
print(empleado.direccion)